<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace Google\Site_Kit_Dependencies\Google\Service\Analytics;

class Account extends \Google\Site_Kit_Dependencies\Google\Model
{
    protected $childLinkType = \Google\Site_Kit_Dependencies\Google\Service\Analytics\AccountChildLink::class;
    protected $childLinkDataType = '';
    /**
     * @var string
     */
    public $created;
    /**
     * @var string
     */
    public $id;
    /**
     * @var string
     */
    public $kind;
    /**
     * @var string
     */
    public $name;
    protected $permissionsType = \Google\Site_Kit_Dependencies\Google\Service\Analytics\AccountPermissions::class;
    protected $permissionsDataType = '';
    /**
     * @var string
     */
    public $selfLink;
    /**
     * @var bool
     */
    public $starred;
    /**
     * @var string
     */
    public $updated;
    /**
     * @param AccountChildLink
     */
    public function setChildLink(\Google\Site_Kit_Dependencies\Google\Service\Analytics\AccountChildLink $childLink)
    {
        $this->childLink = $childLink;
    }
    /**
     * @return AccountChildLink
     */
    public function getChildLink()
    {
        return $this->childLink;
    }
    /**
     * @param string
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }
    /**
     * @return string
     */
    public function getCreated()
    {
        return $this->created;
    }
    /**
     * @param string
     */
    public function setId($id)
    {
        $this->id = $id;
    }
    /**
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }
    /**
     * @param string
     */
    public function setKind($kind)
    {
        $this->kind = $kind;
    }
    /**
     * @return string
     */
    public function getKind()
    {
        return $this->kind;
    }
    /**
     * @param string
     */
    public function setName($name)
    {
        $this->name = $name;
    }
    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * @param AccountPermissions
     */
    public function setPermissions(\Google\Site_Kit_Dependencies\Google\Service\Analytics\AccountPermissions $permissions)
    {
        $this->permissions = $permissions;
    }
    /**
     * @return AccountPermissions
     */
    public function getPermissions()
    {
        return $this->permissions;
    }
    /**
     * @param string
     */
    public function setSelfLink($selfLink)
    {
        $this->selfLink = $selfLink;
    }
    /**
     * @return string
     */
    public function getSelfLink()
    {
        return $this->selfLink;
    }
    /**
     * @param bool
     */
    public function setStarred($starred)
    {
        $this->starred = $starred;
    }
    /**
     * @return bool
     */
    public function getStarred()
    {
        return $this->starred;
    }
    /**
     * @param string
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }
    /**
     * @return string
     */
    public function getUpdated()
    {
        return $this->updated;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(\Google\Site_Kit_Dependencies\Google\Service\Analytics\Account::class, 'Google\\Site_Kit_Dependencies\\Google_Service_Analytics_Account');
