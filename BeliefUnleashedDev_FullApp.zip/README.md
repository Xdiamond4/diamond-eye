
# BeliefUnleashedDev Fullstack AI Tool

## Features:
- Login-protected chat interface
- GPT-4 backend proxy
- Vercel-ready frontend/backend

## Setup

1. `npm install` in root directory
2. Create `.env` with your OpenAI key
3. Run backend: `node backend/server.js`
4. Access frontend: `http://localhost:3000`

> Vercel serverless functions require minor adaptation to `api` folder structure.
