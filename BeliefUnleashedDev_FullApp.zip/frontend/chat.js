
async function sendMessage() {
  const chat = document.getElementById("chat");
  const input = document.getElementById("userInput");
  const message = input.value;

  if (!message) return;
  appendMessage("You", message);
  input.value = "";

  const token = localStorage.getItem("token");

  const res = await fetch("/api/chat", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ message })
  });

  const data = await res.json();
  appendMessage("BeliefUnleashedDev", data.reply);
}

function appendMessage(sender, message) {
  const chat = document.getElementById("chat");
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("mb-2");
  msgDiv.innerHTML = `<strong>${sender}:</strong> ${message}`;
  chat.appendChild(msgDiv);
  chat.scrollTop = chat.scrollHeight;
}
