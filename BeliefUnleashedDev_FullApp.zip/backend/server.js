
const express = require("express");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const { Configuration, OpenAIApi } = require("openai");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = "supersecret";

const users = {
  danieldentremont: "13011301Jace@$",
  kaylamarshowsky: "ButtzandHuttz1"
};

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("frontend"));

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  if (users[username] && users[username] === password) {
    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: "1h" });
    return res.json({ token });
  }
  res.status(401).json({ message: "Invalid credentials" });
});

app.post("/api/chat", authenticate, async (req, res) => {
  const { message } = req.body;
  const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
  });
  const openai = new OpenAIApi(configuration);

  try {
    const response = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are BeliefUnleashedDev, a helpful developer assistant." },
        { role: "user", content: message }
      ],
    });
    res.json({ reply: response.data.choices[0].message.content });
  } catch (error) {
    res.status(500).json({ message: "Error communicating with OpenAI" });
  }
});

function authenticate(req, res, next) {
  const auth = req.headers["authorization"];
  if (!auth) return res.status(403).json({ message: "Missing token" });

  const token = auth.split(" ")[1];
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(403).json({ message: "Invalid token" });
  }
}

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
